WITH CTE1 as 
(SELECT category, 
                  ROUND((SUM(
                       (CASE WHEN promo_type='BOGOF' THEN `quantity_sold(after_promo)`*2 
						ELSE `quantity_sold(after_promo)` 
                        END -`quantity_sold(before_promo)`)*100)/ SUM(`quantity_sold(before_promo)`)),2)as`ISU %`
FROM fact_events 
JOIN dim_products using (product_code)
JOIN dim_campaigns using (campaign_id)
WHERE campaign_name ='Diwali'
GROUP BY category)

select category, `ISU %`, row_number() over(order by `ISU %` desc) as Rank_
from CTE1;