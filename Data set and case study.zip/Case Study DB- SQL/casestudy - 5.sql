WITH 
CTE1 as (
SELECT product_code,product_name,category, SUM(base_price*`quantity_sold(before_promo)`) as total_revenue_BP,
		SUM(CASE WHEN promo_type="50% OFF" THEN base_price*0.5*`quantity_sold(after_promo)`
			   WHEN promo_type="25% OFF" THEN base_price*0.75*`quantity_sold(after_promo)`
			   WHEN promo_type="33% OFF" THEN base_price*0.67*`quantity_sold(after_promo)`
			   WHEN promo_type="BOGOF" THEN base_price*0.5*2*`quantity_sold(after_promo)`
			   WHEN promo_type="500 Cashback" THEN (base_price-500)*`quantity_sold(after_promo)`
			   ELSE	0
			   END) as total_revenue_AP
FROM fact_events
JOIN dim_products USING (product_code)
GROUP BY category, product_name,product_code),

CTE2 as (
SELECT *,(total_revenue_AP-total_revenue_BP) as Incremental_revenue, Round((total_revenue_AP-total_revenue_BP)/total_revenue_BP*100,2) as `IR %`
FROM CTE1)

SELECT product_code, product_name, category, Incremental_revenue, `IR %`, rank() over(order by `IR %` desc) as Rank_
FROM CTE2
limit 5
