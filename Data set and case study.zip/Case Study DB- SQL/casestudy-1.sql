     SELECT DISTINCT(product_name), base_price
     FROM fact_events
     JOIN dim_products 
     USING (product_code)